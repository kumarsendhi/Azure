Import-Module AADGraph -WarningAction SilentlyContinue -Force

$aadTenant = Read-Host -Prompt "Enter the name of your Azure AD Tenant" 

if($aadTenant -eq "" -or $aadTenant -eq $null) {
    Write-Error "You must specify the name of your Azure AD Tenant"
    return
}


# Login with Azure AD Global Admin
Connect-AAD 

New-AADUser -displayName "Brian Jones" `
            -city "Redmond" `
            -state "WA" `
            -jobTitle "Senior Developer" `
            -accountEnabled $true `
            -mailNickname "bjones" `
            -password "demo@pass1" `
            -givenName "Brian" `
            -surname "Jones" `
            -userPrincipalName "bjones@$aadTenant.onmicrosoft.com"

New-AADUser -displayName "Jennifer Smith" `
            -city "Irving" `
            -state "TX" `
            -jobtitle "Senior DevOps Engineer" `
            -accountEnabled $true `
            -mailNickname "jsmith" `
            -password "demo@pass1" `
            -givenName "Jennifer" `
            -surname "Smith" `
            -userPrincipalName "jsmith@$aadTenant.onmicrosoft.com"


Set-AADUserThumbnailPhoto -Id "bjones@$aadTenant.onmicrosoft.com" -ThumbnailPhotoFilePath "bjones.jpg"
Set-AADUserThumbnailPhoto -Id "jsmith@$aadTenant.onmicrosoft.com" -ThumbnailPhotoFilePath "jsmith.jpg"