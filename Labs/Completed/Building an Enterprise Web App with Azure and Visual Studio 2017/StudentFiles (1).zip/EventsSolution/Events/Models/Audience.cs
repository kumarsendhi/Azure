﻿namespace Events.Models
{
    public enum AudienceType
    {
        IT = 0, 
        Developer = 1, 
        Marketing = 2, 
        Sales = 3
    }
}