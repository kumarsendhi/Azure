﻿## Make a file direcotry for your Modules ##
mkdir 'C:\PS cmdlets'

## Save AuthoringToolkit locally to the system ##
Save-Module -Name AzureAutomationAuthoringToolkit -Path 'C:\PS cmdlets'

## Install Toolkit in PowerShell ISE ##
Install-Module -Name AzureAutomationAuthoringToolkit

## Set the Add on to run when ISE is launched ##
Install-AzureAutomationIseAddOn 