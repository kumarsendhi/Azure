workflow OMSAlertTrigger
{
    param([object]$WebhookData)

    Write-Output $WebhookData.WebhookName
    Write-Output $WebhookData.RequestHeader
    Write-Output $WebhookData.RequestBody
}